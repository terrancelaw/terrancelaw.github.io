library(coin)
library(MASS)

# load data
data = read.csv("six measures.csv")
data$subjectID = factor(data$subjectID)
contingency.table = table(data$condition, data$flaw) 

# agreement(reasonable)
kruskal_test(reasonable ~ condition, data=data, distribution="asymptotic")
c.v = wilcox.test(data[data$condition == "claim-only",]$reasonable, data[data$condition == "claim-vis",]$reasonable, exact=FALSE)
v.d = wilcox.test(data[data$condition == "claim-vis",]$reasonable, data[data$condition == "claim-vis-description",]$reasonable, exact=FALSE)
d.w = wilcox.test(data[data$condition == "claim-vis-description",]$reasonable, data[data$condition == "claim-vis-description-warning",]$reasonable, exact=FALSE)
c.d = wilcox.test(data[data$condition == "claim-only",]$reasonable, data[data$condition == "claim-vis-description",]$reasonable, exact=FALSE)
c.w = wilcox.test(data[data$condition == "claim-only",]$reasonable, data[data$condition == "claim-vis-description-warning",]$reasonable, exact=FALSE)
v.w = wilcox.test(data[data$condition == "claim-vis",]$reasonable, data[data$condition == "claim-vis-description-warning",]$reasonable, exact=FALSE)
p.adjust(c(c.v$p.value, v.d$p.value, d.w$p.value, c.d$p.value, c.w$p.value, v.w$p.value), method="holm")

# agreement(unreasonable)
kruskal_test(unreasonable ~ condition, data=data, distribution="asymptotic")
c.v = wilcox.test(data[data$condition == "claim-only",]$unreasonable, data[data$condition == "claim-vis",]$unreasonable, exact=FALSE)
v.d = wilcox.test(data[data$condition == "claim-vis",]$unreasonable, data[data$condition == "claim-vis-description",]$unreasonable, exact=FALSE)
d.w = wilcox.test(data[data$condition == "claim-vis-description",]$unreasonable, data[data$condition == "claim-vis-description-warning",]$unreasonable, exact=FALSE)
c.d = wilcox.test(data[data$condition == "claim-only",]$unreasonable, data[data$condition == "claim-vis-description",]$unreasonable, exact=FALSE)
c.w = wilcox.test(data[data$condition == "claim-only",]$unreasonable, data[data$condition == "claim-vis-description-warning",]$unreasonable, exact=FALSE)
v.w = wilcox.test(data[data$condition == "claim-vis",]$unreasonable, data[data$condition == "claim-vis-description-warning",]$unreasonable, exact=FALSE)
p.adjust(c(c.v$p.value, v.d$p.value, d.w$p.value, c.d$p.value, c.w$p.value, v.w$p.value), method="holm")

# agreement(hard to tell)
kruskal_test(hardToTell ~ condition, data=data, distribution="asymptotic")
c.v = wilcox.test(data[data$condition == "claim-only",]$hardToTell, data[data$condition == "claim-vis",]$hardToTell, exact=FALSE)
v.d = wilcox.test(data[data$condition == "claim-vis",]$hardToTell, data[data$condition == "claim-vis-description",]$hardToTell, exact=FALSE)
d.w = wilcox.test(data[data$condition == "claim-vis-description",]$hardToTell, data[data$condition == "claim-vis-description-warning",]$hardToTell, exact=FALSE)
c.d = wilcox.test(data[data$condition == "claim-only",]$hardToTell, data[data$condition == "claim-vis-description",]$hardToTell, exact=FALSE)
c.w = wilcox.test(data[data$condition == "claim-only",]$hardToTell, data[data$condition == "claim-vis-description-warning",]$hardToTell, exact=FALSE)
v.w = wilcox.test(data[data$condition == "claim-vis",]$hardToTell, data[data$condition == "claim-vis-description-warning",]$hardToTell, exact=FALSE)
p.adjust(c(c.v$p.value, v.d$p.value, d.w$p.value, c.d$p.value, c.w$p.value, v.w$p.value), method="holm")

# trust
kruskal_test(trust ~ condition, data=data, distribution="asymptotic")

# awareness of system's flaws
chisq.test(contingency.table)

# awareness of "correlation is not causation"
kruskal_test(awareness ~ condition, data=data, distribution="asymptotic")
c.v = wilcox.test(data[data$condition == "claim-only",]$awareness, data[data$condition == "claim-vis",]$awareness, exact=FALSE)
v.d = wilcox.test(data[data$condition == "claim-vis",]$awareness, data[data$condition == "claim-vis-description",]$awareness, exact=FALSE)
d.w = wilcox.test(data[data$condition == "claim-vis-description",]$awareness, data[data$condition == "claim-vis-description-warning",]$awareness, exact=FALSE)
c.d = wilcox.test(data[data$condition == "claim-only",]$awareness, data[data$condition == "claim-vis-description",]$awareness, exact=FALSE)
c.w = wilcox.test(data[data$condition == "claim-only",]$awareness, data[data$condition == "claim-vis-description-warning",]$awareness, exact=FALSE)
v.w = wilcox.test(data[data$condition == "claim-vis",]$awareness, data[data$condition == "claim-vis-description-warning",]$awareness, exact=FALSE)
p.adjust(c(c.v$p.value, v.d$p.value, d.w$p.value, c.d$p.value, c.w$p.value, v.w$p.value), method="holm")
