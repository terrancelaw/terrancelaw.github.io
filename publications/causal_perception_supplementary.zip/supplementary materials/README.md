The supplementary materials contain three folders (pre-study, study 1, and study 2) and one pdf file (how we pay participants?.pdf).

The "pre-study" folder contains the screenshots of the experiment interface, the dataset, and the ranked lists of 90 causal claims.

The "study 1" folder contains the screenshots of the experiment interface, quantitative data, data analysis script, and qualitative results.

The "study 2" folder contains the screenshots of the experiment interface, quantitative data, data analysis script, and qualitative results.

"how we pay participants?.pdf" shows some reviews from our participants on turkerview.com and provides evidence for fair pay.