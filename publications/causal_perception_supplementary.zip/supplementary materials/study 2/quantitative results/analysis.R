library(coin)
library(MASS)

# load data
data = read.csv("four measures.csv")
data$subjectID = factor(data$subjectID)
contingency.table = table(data$condition, data$flaw) 

# agreement(reasonable)
kruskal_test(reasonable ~ condition, data=data, distribution="asymptotic")

# trust
kruskal_test(trust ~ condition, data=data, distribution="asymptotic")

# awareness of system's flaws
chisq.test(contingency.table)

# awareness of "correlation is not causation"
kruskal_test(awareness ~ condition, data=data, distribution="asymptotic")